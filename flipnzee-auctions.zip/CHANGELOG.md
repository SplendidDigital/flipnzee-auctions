# Changelog

## Version 1.0.0

- Initial project setup
